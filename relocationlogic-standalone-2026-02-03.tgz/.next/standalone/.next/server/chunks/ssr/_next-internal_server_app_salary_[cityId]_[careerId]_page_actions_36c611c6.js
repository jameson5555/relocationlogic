module.exports=[43941,(a,b,c)=>{}];

//# sourceMappingURL=_next-internal_server_app_salary_%5BcityId%5D_%5BcareerId%5D_page_actions_36c611c6.js.map