:HL["/_next/static/chunks/9abc0ddca4a6a13d.css","style"]
0:{"buildId":"mZZB6c8NLg1DnM_fDwn_V","tree":{"name":"","paramType":null,"paramKey":"","hasRuntimePrefetch":false,"slots":{"children":{"name":"__PAGE__","paramType":null,"paramKey":"__PAGE__","hasRuntimePrefetch":false,"slots":null,"isRootLayout":false}},"isRootLayout":true},"staleTime":300}
