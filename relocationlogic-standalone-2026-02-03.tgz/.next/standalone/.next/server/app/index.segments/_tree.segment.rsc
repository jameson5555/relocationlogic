:HL["/_next/static/chunks/9abc0ddca4a6a13d.css","style"]
0:{"buildId":"LsUEp5rkOfI4bRgwxZRa-","tree":{"name":"","paramType":null,"paramKey":"","hasRuntimePrefetch":false,"slots":{"children":{"name":"__PAGE__","paramType":null,"paramKey":"__PAGE__","hasRuntimePrefetch":false,"slots":null,"isRootLayout":false}},"isRootLayout":true},"staleTime":300}
